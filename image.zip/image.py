import os
import cv2
from PIL import Image
from transformers import pipeline
from huggingface_hub import hf_hub_download, list_repo_files
from ultralytics import YOLO

# ==========================================
# 1. LOAD AI IMAGE DETECTOR
# ==========================================
AI_MODEL_NAME = "umm-maybe/AI-image-detector"

print(f"Loading AI Classifier model ('{AI_MODEL_NAME}')...")
try:
    ai_detector = pipeline("image-classification", model=AI_MODEL_NAME)
    print("AI Detector pipeline loaded successfully.")
except Exception as e:
    print(f"Warning: Could not load AI Detector ({e}). AI verification will be skipped.")
    ai_detector = None

def check_ai_generated(image_input, confidence_threshold=0.50):
    """
    Checks if an input image or OpenCV frame is AI-generated.
    Returns: dict {"is_ai": bool, "label": str, "confidence": float}
    """
    if ai_detector is None:
        return {"is_ai": False, "label": "unknown", "confidence": 0.0}

    # Convert path or OpenCV frame (BGR) to PIL Image (RGB)
    if isinstance(image_input, str):
        if not os.path.exists(image_input):
            return {"is_ai": False, "label": "not_found", "confidence": 0.0}
        pil_img = Image.open(image_input).convert("RGB")
    elif isinstance(image_input, Image.Image):
        pil_img = image_input.convert("RGB")
    else:  # OpenCV numpy frame
        rgb_frame = cv2.cvtColor(image_input, cv2.COLOR_BGR2RGB)
        pil_img = Image.fromarray(rgb_frame)

    # Inference via Hugging Face Pipeline
    results = ai_detector(pil_img)
    top_prediction = results[0]
    
    label = top_prediction['label'].lower()
    score = top_prediction['score']

    # Detect AI classification keywords
    is_ai = any(kw in label for kw in ['artificial', 'fake', 'ai', 'synthetic']) and score >= confidence_threshold

    return {
        "is_ai": is_ai,
        "label": top_prediction['label'],
        "confidence": round(score * 100, 2)
    }

def draw_ai_warning(frame, confidence_score):
    """
    Draws a red warning banner across the top of the frame.
    """
    annotated = frame.copy()
    h, w, _ = annotated.shape
    
    # Red top header rectangle
    header_height = max(60, int(h * 0.08))
    cv2.rectangle(annotated, (0, 0), (w, header_height), (0, 0, 220), -1)
    
    # Notification text
    text = f"This is an AI generated image ({confidence_score:.1f}%)"
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = max(0.6, w / 1100.0)
    thickness = 2
    
    # Position text centered in header
    (text_w, text_h), _ = cv2.getTextSize(text, font, font_scale, thickness)
    text_x = max(10, (w - text_w) // 2)
    text_y = (header_height + text_h) // 2
    
    cv2.putText(annotated, text, (text_x, text_y), font, font_scale, (255, 255, 255), thickness)
    return annotated

# ==========================================
# 2. DOWNLOAD POTHOLE DETECTOR FROM HUGGING FACE
# ==========================================
REPO_ID = "Vansh180/PotholeNet-V1"
print(f"Checking repository: {REPO_ID}...")

try:
    repo_files = list_repo_files(repo_id=REPO_ID)
    pt_files = [f for f in repo_files if f.endswith(".pt")]
    
    if not pt_files:
        raise FileNotFoundError("No .pt weights file found in the repository.")
    
    weights_filename = pt_files[0]
    print(f"Found model file: '{weights_filename}'. Downloading...")
    weights_path = hf_hub_download(repo_id=REPO_ID, filename=weights_filename)

except Exception as e:
    print(f"Warning: Could not fetch from {REPO_ID} ({e}).")
    print("Falling back to standard YOLO base model (yolov8n.pt)...")
    weights_path = "yolov8n.pt"

# ==========================================
# 3. LOAD POTHOLE MODEL ON CPU
# ==========================================
print("Loading PotholeNet model into memory...")
model = YOLO(weights_path)
print("Model loaded successfully. Class Mapping:", model.names)

# ==========================================
# 4. CONFIGURATION & INPUT SETTINGS
# ==========================================
# Options: Folder path, Image path, Video path, or Webcam index (0)
INPUT_SOURCE = "./Sample_images"  # Change this to your desired input source (folder, image, video, or webcam index)    

WINDOW_NAME = "Civic Issue Detector (PotholeNet)"
IMAGE_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.bmp', '.webp', '.tiff')

CONF_THRESHOLD = 0.15
INFERENCE_SIZE = 1024
IOU_THRESHOLD = 0.45

def process_frame(frame, model, conf=CONF_THRESHOLD, imgsz=INFERENCE_SIZE, iou=IOU_THRESHOLD):
    """Runs YOLO object detection on authentic frames."""
    results = model(
        frame, 
        device="cpu", 
        conf=conf, 
        imgsz=imgsz, 
        iou=iou, 
        verbose=False
    )
    annotated_frame = frame.copy()

    for result in results:
        for box in result.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            
            cls_id = int(box.cls[0])
            class_name = model.names[cls_id]
            confidence = float(box.conf[0])
            
            box_color = (0, 255, 255) if "garbage" in class_name.lower() else (0, 0, 255)

            # 1. Draw Bounding Box Rectangle
            cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), box_color, 4)

            # 2. Labeling
            label_text = f"{class_name.upper()} {confidence:.2f}"
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 0.7
            font_thickness = 2
            
            (text_w, text_h), _ = cv2.getTextSize(label_text, font, font_scale, font_thickness)
            text_y1 = max(y1 - 10, text_h + 10)
            
            cv2.rectangle(annotated_frame, (x1, text_y1 - text_h - 5), (x1 + text_w + 10, text_y1 + 5), box_color, -1)
            cv2.putText(annotated_frame, label_text, (x1 + 5, text_y1), font, font_scale, (0, 0, 0), font_thickness)

    return annotated_frame

def evaluate_and_process(image_input):
    """
    Evaluates frame for AI classification.
    If AI-generated -> Notifies user and displays warning overlay.
    If Real -> Passes frame to PotholeNet detection.
    """
    if isinstance(image_input, str):
        frame = cv2.imread(image_input)
    else:
        frame = image_input

    if frame is None:
        return None, False

    # 1. Check AI Generation
    ai_check = check_ai_generated(image_input, confidence_threshold=0.50)

    if ai_check["is_ai"]:
        print(f"\n[ALERT] This is an AI generated image (Confidence: {ai_check['confidence']}%)")
        output_frame = draw_ai_warning(frame, ai_check['confidence'])
        return output_frame, True
    else:
        # 2. Run Civic Issue Detection if real
        output_frame = process_frame(frame, model)
        return output_frame, False

# ==========================================
# 5. EXECUTION PIPELINE
# ==========================================
if isinstance(INPUT_SOURCE, str) and os.path.isdir(INPUT_SOURCE):
    # --------------------------------------
    # FOLDER OF IMAGES PROCESSING
    # --------------------------------------
    image_files = [
        f for f in os.listdir(INPUT_SOURCE) 
        if f.lower().endswith(IMAGE_EXTENSIONS)
    ]
    
    if not image_files:
        print(f"[ERROR] No supported image files found in folder: '{INPUT_SOURCE}'")
        exit()

    output_dir = os.path.join(INPUT_SOURCE, "annotated_results")
    os.makedirs(output_dir, exist_ok=True)

    cv2.namedWindow(WINDOW_NAME, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(WINDOW_NAME, 960, 540)

    print(f"\nFound {len(image_files)} image(s) in folder '{INPUT_SOURCE}'.")
    print("--- Controls ---")
    print("Press ANY KEY (or Space) -> Next image")
    print("Press 's'               -> Save result to 'annotated_results/'")
    print("Press 'q'               -> Quit\n")

    for idx, filename in enumerate(image_files, 1):
        file_path = os.path.join(INPUT_SOURCE, filename)
        print(f"[{idx}/{len(image_files)}] Analyzing: {filename}")

        output_frame, is_ai = evaluate_and_process(file_path)

        if output_frame is None:
            print(f"  --> Failed to read '{filename}', skipping...")
            continue

        cv2.imshow(WINDOW_NAME, output_frame)
        
        key = cv2.waitKey(0) & 0xFF
        if key == ord('q'):
            print("Exiting pipeline.")
            break
        elif key == ord('s'):
            save_path = os.path.join(output_dir, f"annotated_{filename}")
            cv2.imwrite(save_path, output_frame)
            print(f"  --> Saved output to: {save_path}")

    cv2.destroyAllWindows()

elif isinstance(INPUT_SOURCE, str) and INPUT_SOURCE.lower().endswith(IMAGE_EXTENSIONS):
    # --------------------------------------
    # SINGLE IMAGE PROCESSING
    # --------------------------------------
    if not os.path.exists(INPUT_SOURCE):
        print(f"\n[ERROR] Image file '{INPUT_SOURCE}' was not found.")
        exit()

    print(f"Analyzing single image: {INPUT_SOURCE}")
    output_frame, is_ai = evaluate_and_process(INPUT_SOURCE)

    if output_frame is not None:
        cv2.namedWindow(WINDOW_NAME, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(WINDOW_NAME, 960, 540)
        cv2.imshow(WINDOW_NAME, output_frame)
        
        print("\nPress 's' to save or any other key to exit.")
        key = cv2.waitKey(0) & 0xFF
        if key == ord('s'):
            save_path = "detected_output.jpg"
            cv2.imwrite(save_path, output_frame)
            print(f"Saved to: {os.path.abspath(save_path)}")

        cv2.destroyAllWindows()

else:
    # --------------------------------------
    # VIDEO STREAM / WEBCAM PROCESSING
    # --------------------------------------
    if isinstance(INPUT_SOURCE, str) and not os.path.exists(INPUT_SOURCE):
        print(f"\n[ERROR] Video source '{INPUT_SOURCE}' not found.")
        exit()

    cap = cv2.VideoCapture(INPUT_SOURCE)
    cv2.namedWindow(WINDOW_NAME, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(WINDOW_NAME, 960, 540)

    print("Starting video analysis. Press 'q' to stop.")

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            print("End of video stream reached.")
            break

        output_frame, is_ai = evaluate_and_process(frame)

        if output_frame is not None:
            cv2.imshow(WINDOW_NAME, output_frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    print("Pipeline closed successfully.")